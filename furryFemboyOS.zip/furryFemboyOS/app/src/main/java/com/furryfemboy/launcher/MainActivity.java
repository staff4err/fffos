package com.furryfemboy.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // bg, iconBg, accent, text, shape
    private static final int[][] THEMES = {
            {0xFFFBEAF0, 0xFFF4C0D1, 0xFF993556, 0xFF4B1528, 0xFFED93B1},
            {0xFFEEEDFE, 0xFFCECBF6, 0xFF534AB7, 0xFF26215C, 0xFFAFA9EC},
            {0xFFE1F5EE, 0xFF9FE1CB, 0xFF0F6E56, 0xFF04342C, 0xFF5DCAA5},
            {0xFFE6F1FB, 0xFFB5D4F4, 0xFF185FA5, 0xFF042C53, 0xFF85B7EB}
    };
    private static final String[] NAMES = {"Зефир", "Лаванда", "Мята", "Небо"};

    private static class AppItem {
        String label;
        String pkg;
        Drawable icon;
        Intent intent;
    }

    private static class WallpaperView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private int shape = 0xFFED93B1;

        WallpaperView(Context c) {
            super(c);
        }

        void setShape(int color) {
            shape = color;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((shape & 0x00FFFFFF) | (0x70 << 24));
            path.reset();
            path.moveTo(0.08f * w, 0);
            path.lineTo(0.28f * w, 0);
            path.lineTo(0.18f * w, 0.2f * w);
            path.close();
            canvas.drawPath(path, paint);
            path.reset();
            path.moveTo(0.72f * w, 0);
            path.lineTo(0.92f * w, 0);
            path.lineTo(0.82f * w, 0.2f * w);
            path.close();
            canvas.drawPath(path, paint);

            paint.setColor((shape & 0x00FFFFFF) | (0x48 << 24));
            float cx = 0.74f * w;
            float cy = 0.68f * h;
            float r = 0.05f * w;
            canvas.drawOval(cx - 0.15f * w, cy - 0.11f * w, cx + 0.15f * w, cy + 0.11f * w, paint);
            canvas.drawCircle(cx - 0.18f * w, cy - 0.15f * w, r, paint);
            canvas.drawCircle(cx - 0.06f * w, cy - 0.22f * w, r, paint);
            canvas.drawCircle(cx + 0.06f * w, cy - 0.22f * w, r, paint);
            canvas.drawCircle(cx + 0.18f * w, cy - 0.15f * w, r, paint);
        }
    }

    private SharedPreferences prefs;
    private int themeIdx = 0;

    private FrameLayout root;
    private WallpaperView wall;
    private TextClock clock;
    private TextClock date;
    private TextView label;
    private TextView chip;
    private EditText search;
    private GridView grid;
    private LinearLayout dock;
    private final List<TextView> dockItems = new ArrayList<>();

    private List<AppItem> apps = new ArrayList<>();
    private List<AppItem> shown = new ArrayList<>();
    private AppAdapter adapter;

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("ffos", MODE_PRIVATE);
        themeIdx = prefs.getInt("theme", 0) % THEMES.length;

        root = new FrameLayout(this);
        wall = new WallpaperView(this);
        root.addView(wall, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setFitsSystemWindows(true);
        content.setPadding(dp(16), dp(8), dp(16), dp(8));
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        clock = new TextClock(this);
        clock.setFormat12Hour("HH:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 56);
        clock.setGravity(Gravity.CENTER);
        content.addView(clock, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        date = new TextClock(this);
        date.setFormat12Hour("EEEE, d MMMM");
        date.setFormat24Hour("EEEE, d MMMM");
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        date.setGravity(Gravity.CENTER);
        content.addView(date, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        label = new TextView(this);
        label.setText("furryFemboyOS 1.0");
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        label.setGravity(Gravity.CENTER);
        content.addView(label, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        chip = new TextView(this);
        chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        chip.setPadding(dp(14), dp(6), dp(14), dp(6));
        chip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                themeIdx = (themeIdx + 1) % THEMES.length;
                prefs.edit().putInt("theme", themeIdx).apply();
                applyTheme();
            }
        });
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipLp.gravity = Gravity.CENTER_HORIZONTAL;
        chipLp.topMargin = dp(8);
        content.addView(chip, chipLp);

        search = new EditText(this);
        search.setHint("Поиск приложений");
        search.setSingleLine(true);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        search.setPadding(dp(16), 0, dp(16), 0);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        searchLp.topMargin = dp(14);
        searchLp.bottomMargin = dp(14);
        content.addView(search, searchLp);

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                launch(shown.get(position).intent);
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", shown.get(position).pkg, null));
                launch(i);
                return true;
            }
        });
        content.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setPadding(dp(8), dp(4), dp(8), dp(4));
        addDockItem("Звонки", new Intent(Intent.ACTION_DIAL));
        addDockItem("Чаты", Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING));
        addDockItem("Камера", new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
        addDockItem("Веб", Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER));
        LinearLayout.LayoutParams dockLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dockLp.topMargin = dp(10);
        content.addView(dock, dockLp);

        setContentView(root);
        applyTheme();
    }

    private void addDockItem(String text, final Intent intent) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setPadding(0, dp(14), 0, dp(14));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(intent);
            }
        });
        dock.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dockItems.add(t);
    }

    private void launch(Intent intent) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Приложение не найдено", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "Не удалось открыть", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyTheme() {
        int[] t = THEMES[themeIdx];
        root.setBackgroundColor(t[0]);
        wall.setShape(t[4]);
        clock.setTextColor(t[3]);
        date.setTextColor(t[3]);
        label.setTextColor(t[2]);
        chip.setText("Тема: " + NAMES[themeIdx]);
        chip.setTextColor(0xFFFFFFFF);
        chip.setBackground(rounded(t[2], 16));
        search.setBackground(rounded(t[1], 22));
        search.setTextColor(t[3]);
        search.setHintTextColor((t[3] & 0x00FFFFFF) | (0x99 << 24));
        dock.setBackground(rounded(t[1], 28));
        for (TextView d : dockItems) {
            d.setTextColor(t[3]);
        }
        adapter.notifyDataSetChanged();

        Window w = getWindow();
        w.setStatusBarColor(t[0]);
        w.setNavigationBarColor(t[0]);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void loadApps() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN, null);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> infos = pm.queryIntentActivities(main, 0);
                final List<AppItem> list = new ArrayList<>();
                for (ResolveInfo ri : infos) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) {
                        continue;
                    }
                    AppItem a = new AppItem();
                    a.label = String.valueOf(ri.loadLabel(pm));
                    a.pkg = pkg;
                    a.icon = ri.loadIcon(pm);
                    Intent i = new Intent(Intent.ACTION_MAIN);
                    i.addCategory(Intent.CATEGORY_LAUNCHER);
                    i.setClassName(pkg, ri.activityInfo.name);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    a.intent = i;
                    list.add(a);
                }
                Collections.sort(list, new java.util.Comparator<AppItem>() {
                    @Override
                    public int compare(AppItem x, AppItem y) {
                        return x.label.compareToIgnoreCase(y.label);
                    }
                });
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        apps = list;
                        filter(search.getText().toString());
                    }
                });
            }
        }).start();
    }

    private void filter(String q) {
        String needle = q.trim().toLowerCase(Locale.getDefault());
        List<AppItem> out = new ArrayList<>();
        for (AppItem a : apps) {
            if (needle.isEmpty() || a.label.toLowerCase(Locale.getDefault()).contains(needle)) {
                out.add(a);
            }
        }
        shown = out;
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadApps();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        search.setText("");
        search.clearFocus();
        grid.setSelection(0);
    }

    @Override
    public void onBackPressed() {
        search.setText("");
        search.clearFocus();
    }

    private class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int position) {
            return shown.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout cell;
            ImageView img;
            TextView txt;
            if (convertView == null) {
                cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);

                img = new ImageView(MainActivity.this);
                img.setPadding(dp(7), dp(7), dp(7), dp(7));
                cell.addView(img, new LinearLayout.LayoutParams(dp(52), dp(52)));

                txt = new TextView(MainActivity.this);
                txt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
                txt.setSingleLine(true);
                txt.setEllipsize(TextUtils.TruncateAt.END);
                txt.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tl.topMargin = dp(4);
                cell.addView(txt, tl);
            } else {
                cell = (LinearLayout) convertView;
                img = (ImageView) cell.getChildAt(0);
                txt = (TextView) cell.getChildAt(1);
            }
            AppItem a = shown.get(position);
            int[] t = THEMES[themeIdx];
            img.setBackground(rounded(t[1], 16));
            img.setImageDrawable(a.icon);
            txt.setText(a.label);
            txt.setTextColor(t[3]);
            return cell;
        }
    }
}
